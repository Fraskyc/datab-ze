const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 5500; 

app.use(express.static(path.join(__dirname, 'public')));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


const quotes = [
  "Život je jako jízda na kole. Abychom udrželi rovnováhu, musíme se hýbat. - Albert Einstein",
  "Největší sláva není nikdy nepadnout, ale vždy znovu vstát. - Konfucius",
  "Být šťastný znamená nebýt závislý na druhých. - Buddha"
];

app.get('/quote/random', (req, res) => {
  const randomIndex = Math.floor(Math.random() * quotes.length);
  res.json({ quote: quotes[randomIndex] });
});

app.get('/quote/:index', (req, res) => {
  const index = parseInt(req.params.index, 10);
  if (isNaN(index) || index < 0 || index >= quotes.length) {
    return res.status(404).json({ error: 'Citát nebyl nalezen.' });
  }
  res.json({ quote: quotes[index] });
});

app.post('/quote', (req, res) => {
  const newQuote = req.body.quote;
  if (!newQuote) {
    return res.status(400).json({ error: 'Citát nemůže být prázdný.' });
  }
  quotes.push(newQuote);
  res.json({ message: 'Citát byl úspěšně přidán.', quotes });
});

app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint nebyl nalezen.' });
});


app.listen(PORT, () => {
  console.log(`Server běží na http://localhost:${PORT}`);
});
